import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FormService {

  name:String="";
  address:String="";
  pin:String="";

  constructor() { }
}
