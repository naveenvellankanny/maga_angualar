import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormComponentComponent } from './form-component/form-component.component';
import {ReactiveFormsModule} from '@angular/forms';
import { FormShowComponent } from './form-show/form-show.component'


@NgModule({
  declarations: [
    AppComponent,
    FormComponentComponent,
    FormShowComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
