import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormComponentComponent } from './form-component/form-component.component';
import { FormShowComponent } from './form-show/form-show.component';

const routes: Routes = [
  {
    path:'',
    redirectTo:"home",
    pathMatch: 'full'
  },
  {
    path:"home",
    component:FormComponentComponent
  },
{
  path:'next',
  component:FormShowComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
