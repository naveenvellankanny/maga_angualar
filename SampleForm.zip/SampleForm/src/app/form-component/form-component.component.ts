import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { FormService } from '../form.service';

@Component({
  selector: 'app-form-component',
  templateUrl: './form-component.component.html',
  styleUrls: ['./form-component.component.css']
})
export class FormComponentComponent implements OnInit {

  profileForm:FormGroup;
  
  constructor(private service:FormService) { }

  ngOnInit() {
    this.profileForm=new FormGroup({
      'name': new FormControl('',Validators.required),
      'address': new FormControl('',Validators.required),
      'pin':new FormControl('',Validators.required)
    })
  }

  onSubmit(){
    this.service.name=this.profileForm.get('name').value;
    this.service.address=this.profileForm.get('address').value;
    this.service.pin=this.profileForm.get('pin').value
  }


}
