import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Iuser } from './validate/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  productList:Iuser[];
  url:string='assets/UserId.json';
  constructor(private http: HttpClient) { }
  // getUserDetails():Observable<Iuser []>
  // {
  //   return this.http.get<Iuser[]>(this.url);
  // }
  getUserDetails():any{
    this.http.get<Iuser[]>(this.url).subscribe(res=>{
      this.productList=res;
    })
  }

}