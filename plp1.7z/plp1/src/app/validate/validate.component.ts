import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Iuser } from './user';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-validate',
  templateUrl: './validate.component.html',
  styleUrls: ['./validate.component.css']
})
export class ValidateComponent implements OnInit {

  users:Iuser[];
  check:Iuser[];
  id:number;
  name:String;
  password:String;
  type:String;
  var:boolean=false;
  merchant:string="merchant";
  customer:string="customer";
  admin:string="admin";
  constructor(private service:UserService,private router:Router) { }
  ngOnInit() {
    this.service.getUserDetails();
  }
  ValidateDetails()
  {
    for(let p of this.service.productList){
    if(p.id == this.id && p.password==this.password && p.type==this.customer){ 
          this.router.navigate(['/CustomerPath']);
    }
    else if(p.id == this.id && p.password==this.password && p.type==this.merchant){ 
      this.router.navigate(['/MerchantPath']);
    }
    else if(p.id == this.id && p.password==this.password && p.type==this.admin){ 
      this.router.navigate(['/AdminPath']);
    }
  }
}
}
