export interface Iuser
{

    id:number;
    name:String;
    type:String;
    password:String;

}